INSERT INTO user (uname,email,phone,pwd,urole) VALUES ("Preethika","preethika@gmail.com","123454","pr123","Admin");
INSERT INTO user(uname,pwd,email,urole,phone) VALUES ("Rohith","ro123","rohith@gmail.com","Admin","726484");
INSERT INTO user(uname,pwd,email,urole,phone) VALUES ("Shiva","sh124","shiva@gmail.com","User", "3785342");
INSERT INTO user(uname,pwd,email,urole,phone) VALUES ("Sai","sai123","sai@gmail.com","User","327673");
INSERT INTO user(uname,pwd,email,urole,phone) VALUES ("priya","pr123","priya@gmail.com","User","723476");

INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031234","Orange Travels","Arjun","124343","Hyderabad","Warangal","2024-05-01", "1:00 pm",400);
INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031254","November Travels","Bhoopal","1234633","Hyderabad","Bangalore","2024-05-01", "8:00 am",1200);
INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031267","SRL Travels","Rakesh","127243","Warangal","Hyderabad","2024-05-02", "4:00 pm",400);
INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031235","Happy Travels","Ramu","9874343","Hyderabad","Nellore","2024-05-02", "9:00 am",800);
INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031298","Melody Travels","Prabhakar","8984343","Bangalore","Hyderabad","2024-05-01", "3:00 pm",1200);
INSERT INTO bus(bus_number,bus_name,driver,driver_phn,source,destination,date,time,price) VALUES ("TS031258","Orange Travels","Hemanth","3454343","Hyderabad","Tirupati","2024-05-02", "10:00 am",1500);

INSERT INTO booking(id,email,bus_number,pasname,pasage,seatnum,price) VALUES (1,"priya@gmail.com","TS031234","priya",22,3,400)
