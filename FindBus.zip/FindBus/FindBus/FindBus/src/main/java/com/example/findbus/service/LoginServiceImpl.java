package com.example.findbus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.UserRepo;
import com.example.findbus.model.User;

@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private UserRepo urepo;

	@Override
	public User fetchuser(User login){
		
		List<User> list1 = urepo.findAll();
		
		User val = null ;
		

		for(User i: list1) {
			if(login.email.equals(i.email)) {
				if(login.pwd.equals(i.pwd)) {
					val = i ;
				}
			}
		}
	
		return val;
	
	}

}
