package com.example.findbus.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Bus {
	
	@Id
	public String busNumber;
	public String busName;
	public String driver;
	public String driverPhn;
	public String source;
	public String destination;
	public String date;
	public String time;
	public String price;
	
	public String getBusNumber() {
		return busNumber;
	}
	
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getDriverPhn() {
		return driverPhn;
	}
	public void setDriverPhn(String driverPhn) {
		this.driverPhn = driverPhn;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	
	@Override
	public String toString() {
		return "Bus [busNumber=" + busNumber + ", busName=" + busName + ", driver=" + driver + ", driverPhn="
				+ driverPhn + ", source=" + source + ", destination=" + destination + ", date=" + date + ", time="
				+ time + ", price=" + price + "]";
	}
	
}

