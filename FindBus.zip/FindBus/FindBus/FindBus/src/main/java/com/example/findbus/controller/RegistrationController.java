package com.example.findbus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.findbus.model.User;
import com.example.findbus.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService service;
	
	@PostMapping("/adduser")
	public String adduser(User register, Model m) {
		
		String result = service.adduser1(register);
		
		if(result == "True") {
			m.addAttribute("result","Registration completed successfully!");
			
			return "login";
		}
		
		else {
			m.addAttribute("error", "This User Already exists!");
			return "registration";
		}
		
	}
}
