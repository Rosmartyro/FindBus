package com.example.findbus.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.findbus.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, String>{
	
	@Query(value = "select * from user where email=:email and urole=:urole" , nativeQuery = true)
	User findByEmailandRole(String email , String urole);
	
	

}
