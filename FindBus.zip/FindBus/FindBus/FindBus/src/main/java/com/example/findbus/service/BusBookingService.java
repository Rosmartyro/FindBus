package com.example.findbus.service;

import com.example.findbus.model.Bus;

public interface BusBookingService {

	Bus fetchbus(String id);

}
