package com.example.findbus.service;

import com.example.findbus.model.User;

public interface LoginService {

	 public User fetchuser(User login);
	
}
