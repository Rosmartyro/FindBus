package com.example.findbus.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.findbus.model.Booking;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Integer>{

	
	@Query(value = "select * from booking where bus_number=:busNumber " , nativeQuery = true)
	List<Booking> findBybusNumber(String busNumber);

	@Query(value = "select * from booking where pasname=:pasname and pasage=:pasage and bus_number=:busNumber " , nativeQuery = true)
	Booking findByNameAgebusNumber(String pasname, String busNumber, int pasage);
	
	@Query(value = "select * from booking where email=:email " , nativeQuery = true)
	List<Booking> findByEmail(String email);


}
