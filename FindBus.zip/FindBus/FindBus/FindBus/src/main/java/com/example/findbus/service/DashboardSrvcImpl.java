package com.example.findbus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.BusRepo;
import com.example.findbus.model.Bus;

@Service
public class DashboardSrvcImpl implements DashboardService{
	
	
	@Autowired
	private BusRepo busrepo;

	@Override
	public List fetchdetails(Bus bus) {
			
		List buslist2 = busrepo.findByToFromAndDate(bus.source, bus.destination, bus.date);

		return buslist2;
	}

	


}
