package com.example.findbus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.findbus.model.Booking;
import com.example.findbus.model.Bus;
import com.example.findbus.service.BookingConfirmationService;
import com.example.findbus.service.DashboardService;

@Controller
public class DashboardController {

	
	@Autowired
	private DashboardService dashboardservice;
	
	@Autowired
	private BookingConfirmationService mybookingservice;
	
	
	@RequestMapping("/busdetails")
	public String fetchdetails(Bus bus, Model m) {
		
		List busdetails = dashboardservice.fetchdetails(bus);
		
		if(busdetails.isEmpty()) {
			return "notfound";
			
		}
		
		else {
			m.addAttribute("busdetails",busdetails);
			return "busdetails";
		}
		
	}
	
	
	@RequestMapping("/mybooking")
	public String fetchbooking(@RequestParam String email, Model m) {
		
		List<Booking> mybooking = mybookingservice.fetchbooking(email);
		m.addAttribute("mybookings", mybooking);
		
		return "mybookings";
		
	}
}
