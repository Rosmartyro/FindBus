package com.example.findbus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.findbus.model.Bus;
import com.example.findbus.service.BusRegistrationService;

@Controller
public class BusRegistrationController {
	
	@Autowired
	private BusRegistrationService busregistrationservice;
	
	
	
	@RequestMapping("/addbus")
	public String addbus(Bus bus, Model m) {
		
		String busdetails = busregistrationservice.addbus(bus);

		if(busdetails == "True"){
			
			m.addAttribute("result","Bus details are Successfully added into the database!");
			return "admin";
		}
		
		else {
			
			m.addAttribute("error", "This Bus is already scheduled for this Date, please try another date!");
			return "admin";
		}
	}
	
	@RequestMapping("/buslist")
	public String fetchbuslist(Bus bus, Model m) {	
		List<Bus> buslist = busregistrationservice.fetchbuslist();
		System.out.println(buslist);
		m.addAttribute("buslist",buslist);
		return "mybuslist";
	}
	
}
