package com.example.findbus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.findbus.model.Booking;
import com.example.findbus.service.BookingConfirmationService;

@Controller
public class BookingConfirmationController {

	
	@Autowired
	private BookingConfirmationService bookingconfirmationservice;
	
	@RequestMapping("/successpage")
	public String confirmation(Booking booking, Model m) {
		
		String savemsg = bookingconfirmationservice.confirm(booking);
		
		System.out.println(savemsg);

		if(savemsg == "True") {
			m.addAttribute("msg","Hooray! Your Booking has been completed!!");
			
			return "successpage";
		}
		
		else {
			m.addAttribute("error", "You already have a booking with this bus!");
			return "successpage";
		}
		
	}
	
}
