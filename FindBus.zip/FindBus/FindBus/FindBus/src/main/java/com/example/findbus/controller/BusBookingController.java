package com.example.findbus.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.findbus.model.Booking;
import com.example.findbus.model.Bus;
import com.example.findbus.service.BookingConfirmationService;
import com.example.findbus.service.BusBookingService;

@Controller
public class BusBookingController {
	
	@Autowired
	private BusBookingService busbookingservice;
	
	@Autowired
	private BookingConfirmationService checkavailability;
	
	
	@RequestMapping(value = "{id}", method = RequestMethod.GET)
	public String fetchbus(@PathVariable String id, Model m) {
		
		Bus busdetails = busbookingservice.fetchbus(id);
		
		List<Integer> available = checkavailability.availableseats(id);
		
		

		m.addAttribute("bus",busdetails);
		m.addAttribute("seatlist",available);
		
		return "bookingpage";
	}
	
	@RequestMapping("/generate")
	public String payment(Booking booking, Model m) {
		m.addAttribute("booking", booking);
		return "confirm";
		
	}
	
	
}
