package com.example.findbus.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.findbus.model.Bus;

@Repository
public interface BusRepo extends JpaRepository<Bus, String>{

	
	@Query(value = "select * from bus where source=:source and destination=:destination and date=:date " , nativeQuery = true)
	List<Bus> findByToFromAndDate(String source , String destination, String date);
	
	@Query(value = "select * from bus where bus_number=:bus_number and date=:date " , nativeQuery = true)
	Bus findByDateandBusnumber(String bus_number , String date);

}
