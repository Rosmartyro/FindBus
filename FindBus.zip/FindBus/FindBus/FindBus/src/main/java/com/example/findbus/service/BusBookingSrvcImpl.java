package com.example.findbus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.BusRepo;
import com.example.findbus.model.Bus;

@Service
public class BusBookingSrvcImpl implements BusBookingService{

	@Autowired
	private BusRepo busrepo;
	
	
	@Override
	public Bus fetchbus(String id) {
		
		Bus busdet = busrepo.getById(id);
		
		
		return busdet;

}
}