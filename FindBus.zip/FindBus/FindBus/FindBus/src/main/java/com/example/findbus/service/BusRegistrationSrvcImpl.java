package com.example.findbus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.BusRepo;
import com.example.findbus.model.Bus;

@Service
public class BusRegistrationSrvcImpl implements BusRegistrationService{

	
	@Autowired
	private BusRepo busrepo;
	
	
	@Override
	public String addbus(Bus bus) {
		
		String val = "False";
		
		Bus checkbus = busrepo.findByDateandBusnumber(bus.busNumber, bus.date);
		
		if(checkbus != null) {
			return val;
		}
		
		else {
			busrepo.save(bus);
			val = "True";
			return val;
	}
	}
	
	@Override
	public List<Bus> fetchbuslist() {
		
		List<Bus> buslist = busrepo.findAll();
		
		return buslist;
	}

}
