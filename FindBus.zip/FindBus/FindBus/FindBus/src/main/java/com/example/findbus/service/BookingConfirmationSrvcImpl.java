package com.example.findbus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.BookingRepo;
import com.example.findbus.model.Booking;

@Service
public class BookingConfirmationSrvcImpl implements BookingConfirmationService {

	@Autowired
	BookingRepo bookingrepo;
	
	@Override
	public String confirm(Booking booking) {
		
		String val = "False";
		
		Booking confirmbooking = bookingrepo.findByNameAgebusNumber(booking.pasname, booking.busNumber, booking.pasage);
		
		if(confirmbooking != null) {
			return val;
		}

		else {
			bookingrepo.save(booking);
			val = "True";
			return val;
		}
	}
	
	@Override
	public List<Integer> availableseats(String id) {
				
		List<Booking> available = bookingrepo.findBybusNumber(id);
		
		List<Integer> list = new ArrayList<Integer>();
		
		for(int i=1; i<41; i++) {
			list.add(i);
		}
		
		
		for(int j=0; j<available.size(); j++) {
			int val = available.get(j).seatnum;
			
			for(int i=1; i<41;i++) {
				
				if(val == i) {
					list.remove(Integer.valueOf(val));
					i++;
					}
			}
		}
		
		return list;
	}

	@Override
	public List<Booking> fetchbooking(String email) {
		
		List<Booking> mybookings = bookingrepo.findByEmail(email);
		
		return mybookings;
	}
}
