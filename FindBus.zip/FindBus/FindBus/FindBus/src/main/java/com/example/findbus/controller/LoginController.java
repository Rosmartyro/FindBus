package com.example.findbus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.findbus.model.User;
import com.example.findbus.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	
	@RequestMapping("/")
	public String home() {
		return "login";
	}
	
	@RequestMapping("/checkuser")
	public String loginm(User login, Model m) {
		
		String val="null";
		User result = service.fetchuser(login);
	
		if(result.urole.equals("User")){
			m.addAttribute("email",result.email);
			return "dashboard";
		}
		
		else if(result.urole.equals("Admin")){
			return "admin";				
		}
		
		else{
			m.addAttribute("error","Invalid Username or Password. Try Again");
			return "login";
		}
		
	}
}



