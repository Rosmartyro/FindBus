package com.example.findbus.service;

import java.util.List;

import com.example.findbus.model.Bus;

public interface DashboardService {

	public List fetchdetails(Bus bus);

}
