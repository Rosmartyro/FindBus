package com.example.findbus.service;

import java.util.List;

import com.example.findbus.model.Booking;
import com.example.findbus.model.Bus;

public interface BookingConfirmationService {

	String confirm(Booking booking);

	List<Integer> availableseats(String id);

	List<Booking> fetchbooking(String email);

}
