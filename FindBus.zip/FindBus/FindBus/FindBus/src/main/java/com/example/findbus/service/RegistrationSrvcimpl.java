package com.example.findbus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.findbus.Dao.UserRepo;
import com.example.findbus.model.User;

@Service
public class RegistrationSrvcimpl implements RegistrationService {
	
	@Autowired
	private UserRepo urepo;

	@Override
	public String adduser1(User register) {
		
		String val = "False";
		
		User finduser = urepo.findByEmailandRole(register.email, register.urole);
		
		if(finduser != null) {
			return val;
		}
		
		else {
			urepo.save(register);
			val = "True";
			return val;
	}
}
}
