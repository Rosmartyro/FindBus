package com.example.findbus.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int id;
	
	public String email;
	public String busNumber;
	public String pasname;
	public int pasage;
	public int seatnum;
	public int price;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBusNumber() {
		return busNumber;
	}
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
	public String getPasname() {
		return pasname;
	}
	public void setPasname(String pasname) {
		this.pasname = pasname;
	}
	public int getPasage() {
		return pasage;
	}
	public void setPasage(int pasage) {
		this.pasage = pasage;
	}
	
	public int getSeatnum() {
		return seatnum;
	}
	public void setSeatnum(int seatnum) {
		this.seatnum = seatnum;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Booking [id=" + id + ", email=" + email + ", busNumber=" + busNumber + ", pasname=" + pasname
				+ ", pasage=" + pasage + ", seatnum=" + seatnum + ", price=" + price + "]";
	}
	
	
	
	
}
